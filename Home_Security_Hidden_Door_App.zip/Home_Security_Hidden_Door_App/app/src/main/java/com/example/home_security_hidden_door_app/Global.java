package com.example.home_security_hidden_door_app;


public class Global
{
   // public static  String url="http://192.168.0.101:8084/College_Bus_Route/";
    public static  String url="http://192.168.220.129:8084/Home_Security_Hidden_Door_Web/";

}
